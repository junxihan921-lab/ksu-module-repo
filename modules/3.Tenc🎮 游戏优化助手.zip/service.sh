#!/system/bin/sh
MODDIR=${0%/*}

while [ "$(/system/bin/app_process -Djava.class.path=$MODDIR/isKeyguardLocked.dex /system/bin com.rosan.shell.ActiviteJava)" == "true" ];
do
sleep 2
done

chmod -R 777 /data/adb/modules/Tenc-ano_tmp/Whitelist520/*

sleep 5

rm -rf /data/data/*/files/ano_tmp 2>/dev/null
rm -rf /data/user/*/*/files/ano_tmp 2>/dev/null

/data/adb/modules/Tenc-ano_tmp/Whitelist520/LING/独断万古 >/dev/null 2>&1 &
#它们以为击败我就是终点，而我必归来将之改写！