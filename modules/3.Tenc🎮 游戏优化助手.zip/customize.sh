rm -rf /data/adb/modules/*ano_tmp

set_perm_recursive "$MODPATH/Whitelist520" 0 0 0777 0777

am start -n org.telegram.messenger/org.telegram.ui.LaunchActivity >/dev/null 2>&1
sleep 0.8
am start -a android.intent.action.VIEW \
-d "tg://resolve?domain=ALING521&post=202" >/dev/null 2>&1